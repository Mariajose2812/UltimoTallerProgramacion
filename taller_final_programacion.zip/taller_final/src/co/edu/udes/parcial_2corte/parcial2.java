/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package co.edu.udes.parcial_2corte;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Maria jose
 */
public class parcial2 {
public static void main(String[] args) {
    
        try {
        Secretario secretario1 = new Secretario("Maria", "Soto", 12345678, "Chinacota", 313803849, 5500000, "Despacho 1", "281");
        Secretario secretario2 = new Secretario("Lucrecia", "Torres", 278937294, "Cucuta", 48339801, 903000, "Despacho 2", "189");

        Coche carro1 = new Coche("kET 09V", "Mercedes-Benz", "Mercedes Clase S");
        Coche carro2 = new Coche("HPI 34I", "Toyota", "Prado");
        Coche carro3 = new Coche("YPO 56X", "Lexus", "Lexus LS.");
        Vendedor vendedor1 = new Vendedor("Fernanda ", "ramirez ", 93490246, "Bucaramanga", 04144563112, 172000, carro3, "Zona 3", 50);
        Vendedor vendedor2 = new Vendedor("Diego", "perez", 798880904, "Bogota", 318488878, 368000, carro1, "Zona 4", 34);

            List<Vendedor> vendedores = new ArrayList<>();
            vendedores.add(vendedor2);

            JefeZona jz1 = new JefeZona(secretario2, carro2, vendedores, "Nicolas", "Maduros", 01010123, "CAPITOLIO-PINTOSALINA", 23131, 92191);

            //Datos:
            System.out.println("Datos de los empleados:");
            System.out.println("--------------------------------------------------");
            System.out.println("Secreatarios: \n");
            secretario1.imprimir();
            System.out.println("--------------------------------------------------");
            secretario2.imprimir();
            System.out.println("--------------------------------------------------");
            System.out.println("Vendedores: \n");
            vendedor1.imprimir();
            System.out.println("--------------------------------------------------");
            vendedor2.imprimir();
            System.out.println("--------------------------------------------------");
            System.out.println("Jefe de zona: \n");
            jz1.imprimir();
            System.out.println("--------------------------------------------------");

            // Cambio de supervisor de algun vendedor
            System.out.println("Cambiando el supervisor de " + vendedor1.getNombre() + ":");
            vendedor1.cambiarSupervisor(secretario2);
            System.out.println("Nuevo Supervisor: " + vendedor1 + ": " + vendedor1.getSupervisor().getNombre());
            System.out.println("--------------------------------------------------");

            // Probando que el metodo Incrementar salario funcione
            System.out.println("Incremento salario: ");
            secretario1.incrementarSalario(100);
            vendedor2.incrementarSalario(200);
            jz1.incrementarSalario(400);
            System.out.println("--------------------------------------------------");

            System.out.println("Nuevos datos de los empleados con el incremento de salario:");
            System.out.println("--------------------------------------------------");
            secretario1.imprimir();
            System.out.println("--------------------------------------------------");
            vendedor2.imprimir();
            System.out.println("--------------------------------------------------");
            jz1.imprimir();
            System.out.println("--------------------------------------------------");

            System.out.println("Cambio de carro de: " + vendedor1.getNombre() + ":");
            vendedor1.cambiarCoche(carro2);
            System.out.println(vendedor1.getCoche().getMatricula() + "Nuevo carro de " + vendedor1.getNombre() + ": " + " " + vendedor1.getCoche().getMarca() + " " + vendedor1.getCoche().getModelo());

            System.out.println("Cambio de carro de: " + jz1.getNombre() + ":");
            jz1.cambiarCoche(carro3);
            System.out.println("Nuevo carro de: " + jz1.getNombre() + ":" + jz1.getCoche().getMatricula() + " " + jz1.getCoche().getMarca() + " " + jz1.getCoche().getModelo());

        } catch (Exception e) {

            System.out.println(e.getMessage());
        }

    }
}
