/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package co.edu.udes.parcial_1corte;

import java.util.Scanner;

/**
 *
 * @author Maria jose
 */
public class punto_3 {

public static void main(String[] args) {

        try {
            Scanner teclado = new Scanner(System.in);

            System.out.print("Escriba un número : ");
            int numero = teclado.nextInt();

            boolean apilar = false;
            for (int i = 1; i <= numero; i++) {
                if ((i * (i + 1)) / 2 == numero) {
                    apilar = true;
                    break;
                }

            }
            if (apilar) {
                System.out.println("El número " + numero + " puede ser apilar");
            } else {
                System.out.println("El número " + numero + " no puede ser apilar");
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

    }
}
