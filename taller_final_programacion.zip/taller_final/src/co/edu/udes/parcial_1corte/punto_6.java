/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package co.edu.udes.parcial_1corte;

import java.util.Scanner;

/**
 *
 * @author Maria jose
 */
public class punto_6 {

    public static void main(String[] args) {
        try {
            Scanner teclado = new Scanner(System.in);

            System.out.print("Introduce una frase:");
            String frase = teclado.nextLine();
            int numPalabras = 1;
            for (int i = 0; i < frase.length(); i++) {
                if (frase.charAt(i) == ' ') {
                    numPalabras++;
                }
            }
            System.out.println("La frase introducida tiene " + numPalabras + " palabras.");
        } catch (Exception e) {

            System.out.println(e.getMessage());
        }

    }
}
