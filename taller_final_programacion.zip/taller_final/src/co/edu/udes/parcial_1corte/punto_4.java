/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package co.edu.udes.parcial_1corte;

import java.util.Scanner;

/**
 *
 * @author Maria jose
 */
public class punto_4 {

    public static void main(String[] args) {
        
        try {Scanner teclado = new Scanner(System.in);
            System.out.print("Escriba la cantidad de numeros de la serie:");
            int serie = teclado.nextInt();

            int a = 0, b = 1;

            System.out.print("La serie de Fibonacci es: ");
            for (int i = 1; i <= serie; i++) {
                System.out.print(a + " ");
                int c = a + b;
                a = b;
                b = c;
            }

        } catch (Exception e) {
             System.out.println(e.getMessage());
        }
       
    }
}
