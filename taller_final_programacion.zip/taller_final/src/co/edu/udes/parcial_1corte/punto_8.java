/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package co.edu.udes.parcial_1corte;

import java.util.Scanner;

/**
 *
 * @author Maria jose
 */
public class punto_8 {

    public static void main(String[] args) {
        try {
            Scanner teclado = new Scanner(System.in);

            System.out.println("Escriba el nombre de cada asignatura (una por línea, ingrese una línea vacía para finalizar):");
            String linea = teclado.nextLine();
            String[] asignaturas = new String[100];
            int contadorAsignaturas = 0;
            while (!linea.isEmpty()) {
                asignaturas[contadorAsignaturas] = linea;
                contadorAsignaturas++;
                linea = teclado.nextLine();
            }

            int[][] horasEstudio = new int[contadorAsignaturas][12];
            for (int i = 0; i < contadorAsignaturas; i++) {
                
                System.out.println("Escriba las horas de estudio mensuales para " + asignaturas[i] + ":");
                for (int j = 0; j < 12; j++) {
                    System.out.print("Mes " + (j + 1) + ": ");
                    horasEstudio[i][j] = teclado.nextInt();
                }
            }

            int[] totalAnual = new int[contadorAsignaturas];
            for (int i = 0; i < contadorAsignaturas; i++) {
                int total = 0;
                for (int j = 0; j < 12; j++) {
                    total += horasEstudio[i][j];
                }
                totalAnual[i] = total;
            }

            int totalMensual = 0;
            for (int i = 0; i < contadorAsignaturas; i++) {
                for (int j = 0; j < 12; j++) {
                    totalMensual += horasEstudio[i][j];
                }
            }

            int maxTotal = -1;
            int indiceMaxTotal = -1;
            for (int i = 0; i < contadorAsignaturas; i++) {
                if (totalAnual[i] > maxTotal) {
                    maxTotal = totalAnual[i];
                    indiceMaxTotal = i;
                }
            }
            String asignaturaMasEstudiada = asignaturas[indiceMaxTotal];

            System.out.println("Total anual de horas dedicadas a cada asignatura:");
            for (int i = 0; i < contadorAsignaturas; i++) {
                System.out.println(asignaturas[i] + ": " + totalAnual[i]);
            }

            System.out.println("Total mensual de horas dedicadas a estudiar: " + totalMensual);
            System.out.println("Asignatura más estudiada: " + asignaturaMasEstudiada);

        } catch (Exception e) {

            System.out.println(e.getMessage());

        }

    }

}
