/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package co.edu.udes.parcial_1corte;

import java.util.Scanner;

/**
 *
 * @author Maria jose
 */
public class punto_1 {

     public static void main(String[] args) {
         
        try {

            Scanner teclado = new Scanner(System.in);

            System.out.println("Escriba la cantidad de segundos:");
            int segundos = teclado.nextInt();

            int horas = segundos / 3600;
            int minutos = (segundos % 3600) / 60;
            int totalSegundos = segundos % 60;

            System.out.println(segundos + " segundos equivalen a " + horas + " horas, " + minutos + " minutos y " + totalSegundos + " segundos.");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
