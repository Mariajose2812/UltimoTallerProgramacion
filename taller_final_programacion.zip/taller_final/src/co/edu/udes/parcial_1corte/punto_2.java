/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package co.edu.udes.parcial_1corte;

import java.util.Scanner;

/**
 *
 * @author Maria jose
 */
public class punto_2 {
    
 public static void main(String[] args) {

        try {
            Scanner teclado = new Scanner(System.in);

            System.out.println("Escriba el dia:");
            int dia = teclado.nextInt();

            System.out.println("Escriba el mes:");
            int mes = teclado.nextInt();

            System.out.println("Escriba el año:");
            int año = teclado.nextInt();

            boolean fechaValida = true;
            if (mes < 1 || mes > 12) {
                fechaValida = false;
            } else {
                int diasMax;
                if (mes == 2) {
                    if (año % 4 == 0 && (año % 100 != 0 || año % 400 == 0)) {
                        diasMax = 29;
                    } else {
                        diasMax = 28;
                    }
                } else if (mes == 4 || mes == 6 || mes == 9 || mes == 11) {
                    diasMax = 30;
                } else {
                    diasMax = 31;
                }
                if (dia < 1 || dia > diasMax) {
                    fechaValida = false;
                }
            }

            if (fechaValida) {
                System.out.println("La fecha ingresada es válida.");
            } else {
                System.out.println("La fecha ingresada es inválida.");
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

    }
}
