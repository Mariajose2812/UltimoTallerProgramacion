/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package co.edu.udes.Taller_en_clase;

/**
 *
 * @author Maria jose
 */
public class Taller_en_clase {
    
    
public static void main(String[] args) {
        try {
           
            Empleado emp1 = new Empleado("Julia");
            Empleado emp2 = new Operario("Maria");
            Empleado emp3 = new Tecnico("Lucrecia");
            Empleado emp4 = new Supervisor("Luis");
            Empleado emp5 = new Directivo("Alfonso");
            Empleado emp6 = new Secretaria("Patricia");
            Empleado emp7 = new Gerente("Fernanda");

            
            System.out.println(emp1);
            System.out.println(emp2);
            System.out.println(emp3);
            System.out.println(emp4);
            System.out.println(emp5);
            System.out.println(emp6);
            System.out.println(emp7);

            incrementarSalario(emp3, 0.2);
            incrementarSalario(emp4, 0.2);
            incrementarSalario(emp6, 0.2);
            incrementarSalario(emp7, 0.2);
            incrementarSalario(emp2, 0.4);
            incrementarSalario(emp5, 0.4);
            incrementarSalario(emp1, 0.6);

            
            System.out.println("Salarios actualizados:");
            System.out.println(emp1);
            System.out.println(emp2);
            System.out.println(emp3);
            System.out.println(emp4);
            System.out.println(emp5);
            System.out.println(emp6);
            System.out.println(emp7);
        } catch (Exception e) {

            System.out.println(e.getMessage());

        }

    }

    private static void incrementarSalario(Empleado emp3, double d) {
        throw new UnsupportedOperationException("Not supported yet."); 
    }

}
