/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udes.Taller_en_clase;

/**
 *
 * @author Maria jose
 */
public class Supervisor extends Operario {
    public Supervisor(String nombre) {
        super(nombre);
        setSalarioBase(1000);
    }

    public void incrementarSalario() {
        setSalarioBase(getSalarioBase() * 1.2);
    }

    public String toString() {
        return super.toString() + " -> Supervisor D4";
    }
    
}

