/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udes.Taller_en_clase;

/**
 *
 * @author Maria jose
 */
public class Empleado {
      private String nombre;
    private double salarioBase;

    public Empleado() {
        this.nombre = "";
        this.salarioBase = 1000;
    }

    public Empleado(String nombre) {
        this.nombre = nombre;
        this.salarioBase = 1000;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getSalarioBase() {
        return salarioBase;
    }

    public void setSalarioBase(double salarioBase) {
        this.salarioBase = salarioBase;
    }

    public void incrementarSalario() {
        this.salarioBase *= 1.6;
    }

    public String toString() {
        return "Empleado " + nombre;
    }
}




