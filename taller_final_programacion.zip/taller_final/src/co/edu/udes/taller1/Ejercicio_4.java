/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package co.edu.udes.taller1;

import java.util.Scanner;

/**
 *
 * @author Maria jose
 */
public class Ejercicio_4 {

    public static void main(String[] args) {

        try {
            Scanner teclado = new Scanner(System.in);

            System.out.print("Escriba el primer numero:");
            int numero1 = teclado.nextInt();

            System.out.print("Escriba el segundo numero:");
            int numero2 = teclado.nextInt();

            int x = numero1;

            while (x <= numero2) {
                if (x % 2 == 0) {
                    System.out.println("Los numeros pares seran: " + x);
                }
                x++;

            }
        } catch (Exception e) {

            System.out.println(e.getMessage());

        }

    }
}
