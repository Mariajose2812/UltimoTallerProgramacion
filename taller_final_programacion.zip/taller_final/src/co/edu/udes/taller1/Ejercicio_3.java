/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package co.edu.udes.taller1;

import java.util.Scanner;

/**
 *
 * @author Maria jose
 */
public class Ejercicio_3 {

    public static void main(String[] args) {

        try {
            Scanner teclado = new Scanner(System.in);

            char p;

            do {
                System.out.print("Escriba caracteres:");
                p = teclado.nextLine().charAt(0);

                if (p == 'a' || p == 'e' || p == 'i' || p == 'o' || p == 'u' || p == 'A' || p == 'E' || p == 'I' || p == 'O' || p == 'U') {

                    System.out.println("ES UNA VOCAL");
                } else if (p != ' ') {

                    System.out.println(" NO ES UNA VOCAL");

                }

            } while (p != ' ');
            System.out.println("Programa terminado.");
            teclado.close();
        } catch (Exception e) {

            System.out.println(e.getMessage());

        }

    }
}
