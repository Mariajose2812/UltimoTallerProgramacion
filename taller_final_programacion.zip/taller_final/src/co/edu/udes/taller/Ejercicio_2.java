/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package co.edu.udes.taller;

import java.util.Scanner;

/**
 *
 * @author Maria jose
 */
public class Ejercicio_2 {

    public static void main(String[] args) {
        try {
            Scanner teclado = new Scanner(System.in);

            System.out.print("Escriba el numero :");
            int numero1 = teclado.nextInt();

            if (numero1 % 2 == 0) {
                System.out.print("El numero es par ");
            } else {

                System.out.print("El  numero es impar");
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

    }
}
