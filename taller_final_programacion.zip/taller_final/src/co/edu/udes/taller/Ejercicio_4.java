/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package co.edu.udes.taller;

import java.util.Scanner;

/**
 *
 * @author Maria jose
 */
public class Ejercicio_4 {

    public static void main(String[] args) {
        try {
            Scanner teclado = new Scanner(System.in);
            System.out.print("Digite la cadena de texto: ");
            String palabra = teclado.nextLine();

            boolean hayMayuscula = false;
            for (int i = 0; i < palabra.length(); i++) {
                char letra = palabra.charAt(i);
                if (Character.isUpperCase(letra)) {
                    hayMayuscula = true;
                    System.out.println(letra + " es una letra mayúscula");
                }
            }

            if (!hayMayuscula) {
                System.out.println("No se encontraron letras mayúsculas.");
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

    }
}

