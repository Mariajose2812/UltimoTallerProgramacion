/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udes.cine;

/**
 *
 * @author Maria jose
 */
public class Employee {
    private String name;
   private String document;
   private int phone;
   private int type_of_employee;
   private String code;
   private double salary;
   private String schedule;

    public Employee(String name, String document, double salary, String code, String schedule, String code1, String schedule1) {
        this.name = name;
        this.document = document;
        this.phone = phone;
        this.type_of_employee = type_of_employee;
        this.code = code;
        this.salary = salary;
        this.schedule = schedule;
    }

    public String getName() {
        return name;
    }

    public String getDocument() {
        return document;
    }

    public int getPhone() {
        return phone;
    }

    public int getType_of_employee() {
        return type_of_employee;
    }

    public String getCode() {
        return code;
    }
    
    

    public void setName(String name) {
        this.name = name;
    }

    public void setDocument(String document) {
        this.document = document;
    }

    public void setPhone(int phone) {
        this.phone = phone;
    }

    public void setType_of_employee(int type_of_employee) {
        this.type_of_employee = type_of_employee;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public void setSchedule(String schedule) {
        this.schedule = schedule;
    }

    public double getSalary() {
        return salary;
    }

    public String getSchedule() {
        return schedule;
    }
  @Override
    public String toString() {
        return "employee{" + "name=" + name + ", document=" + document + ", phone=" + phone+ ",type_of_employee =" + type_of_employee + ",code=" + code+",salary=" + salary +",schedule="+schedule + '}';
    }
    
}


