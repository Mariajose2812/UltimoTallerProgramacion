/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udes.cine;

/**
 *
 * @author Maria jose
 */
public class schedule {
    private String children_schedule;
    private String family_hours;
    private String festive;

    public schedule(String children_schedule, String family_hours, String festive) {
        this.children_schedule = children_schedule;
        this.family_hours = family_hours;
        this.festive = festive;
    }

    public String getChildren_schedule() {
        return children_schedule;
    }

    public String getFamily_hours() {
        return family_hours;
    }

    public String getFestive() {
        return festive;
    }

    
    
    
    public void setChildren_schedule(String children_schedule) {
        this.children_schedule = children_schedule;
    }

    public void setFamily_hours(String family_hours) {
        this.family_hours = family_hours;
    }

    public void setFestive(String festive) {
        this.festive = festive;
    }
     @Override
    public String toString() {
        return "schedule{" + "children_schedule=" + children_schedule + ", family_hours=" +family_hours + ", festive=" + festive + '}';
    }
}
  


