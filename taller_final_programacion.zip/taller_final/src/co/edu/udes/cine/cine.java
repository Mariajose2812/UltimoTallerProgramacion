/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package co.edu.udes.cine;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

/**
 *
 * @author Maria jose 
 */
public class cine {

    public static void main(String[] args) {
        
       
            
        
        Scanner teclado = new Scanner(System.in);
        
        box[] boxes = null;
        Sala[] salas = null;
        Ticket[] tickets = null;
        Movie[] movies = null;
        Employee[] employees = null;
        Customer[] customers = null;
        food[] foods = null;
        schedule [] schedules = null;

        int boxesAgregados = 0;
        int ticketsAgregados = 0;
        int salasAgregadas = 0;
        int employeesAgregados = 0;
        int customersAgregados = 0;
        int moviesAgregados = 0;
         int foodsAgregados= 0;
        int schedulesAgregados;

        boolean salir = false;

        while (!salir) {
            int menu = mostrarMenu(teclado);
            int subMenu = 0; // inicializar subMenu a cero

            switch (menu) {
                case 1:
                    System.out.println("Bienvenido al Sistema de cine");
                    if (salas == null) {
                        System.out.println("Digite la cantidad maxima de Salas que desea agregar.");
                        salas = new Sala[teclado.nextInt()];
                    } else {
                        System.out.println("Hay registrados " + salasAgregadas + " salas");
                    }
                    subMenu = mostrarSubMenu(teclado, menu, salas, salasAgregadas);
                    // mover la seleccion de submenu aqui, luego de la validacion de si hay salas agregadas

                    switch (subMenu) {
                        case 1:
                            listarSalas(salas);
                            break;
                        case 2:
                            salas = agregarSala(teclado, salas, salasAgregadas);
                            salasAgregadas++;
                            listarSalas(salas);
                            break;
                        case 3:
                            salir = true;
                            break;
                    }
                    break;
                case 2:
                   
                    if (tickets == null) {
                        System.out.println("Digite la cantidad maxima de tickets que desea agregar.");
                        tickets = new Ticket[teclado.nextInt()];
                    } else {
                        System.out.println("Hay registrados " + ticketsAgregados + " tickets");
                    }
                    subMenu = mostrarSubMenuTickets(teclado, menu, tickets, ticketsAgregados);
                    // mover la seleccion de submenu aqui, luego de la validacion de si hay tickets agregados

                    switch (subMenu) {
                        case 1:
                            listarTickets(tickets);
                            break;
                        case 2:
                            tickets = agregarTicket(teclado, tickets, ticketsAgregados);
                            ticketsAgregados++;
                            listarTickets(tickets);
                            break;
                        case 3:
                            salir = true;
                            break;
                    }
                    break;
                    
                case 3:
                    
                    if (movies == null) {
                        System.out.println("Digite la cantidad maxima de peliculas que desea agregar.");
                        movies = new Movie[teclado.nextInt()];
                    } else {
                        System.out.println("Hay registrados " + moviesAgregados + " peliculas");
                    }
                    subMenu = mostrarSubMenuMovies(teclado, menu, movies, moviesAgregados);
                    // mover la seleccion de submenu aqui, luego de la validacion de si hay tickets agregados

                    switch (subMenu) {
                        case 1:
                            listarMovie(movies);
                            break;
                        case 2:
                            movies = agregarMovie(teclado,movies, moviesAgregados);
                            moviesAgregados++;
                            listarMovie(movies);
                            break;
                        case 3:
                            salir = true;
                            break;
                    }
                    break;
                    
                case 4:
                     
                    if (employees == null) {
                        System.out.println("Digite la cantidad maxima de empleados que desea agregar.");
                        employees = new Employee[teclado.nextInt()];
                    } else {
                        System.out.println("Hay registrados " + employeesAgregados + " empleados");
                    }
                    subMenu = mostrarSubMenuEmployee(teclado, menu, employees, employeesAgregados);
                    // mover la seleccion de submenu aqui, luego de la validacion de si hay tickets agregados

                    switch (subMenu) {
                        case 1:
                            listarEmployee(employees);
                            break;
                        case 2:
                            employees = agregarEmployee(teclado,employees, employeesAgregados);
                            employeesAgregados++;
                            listarEmployee(employees);
                            break;
                        case 3:
                            salir = true;
                            break;
                    }
                    break;
                    
                case 5:
                     if (customers == null) {
                        System.out.println("Digite la cantidad maxima de clientes que desea agregar.");
                        customers = new Customer[teclado.nextInt()];
                    } else {
                        System.out.println("Hay registrados " + customersAgregados + " clientes");
                    }
                    subMenu = mostrarSubMenuCustomer(teclado, menu, customers, customersAgregados);
                    // mover la seleccion de submenu aqui, luego de la validacion de si hay tickets agregados

                    switch (subMenu) {
                        case 1:
                            listarCustomer(customers);
                            break;
                        case 2:
                            customers = agregarCustomer(teclado,customers, customersAgregados);
                            customersAgregados++;
                            listarCustomer(customers);
                            break;
                        case 3:
                            salir = true;
                            break;
                    }
                    break;
                    
                case 6:
                    
                    if (foods == null) {
                        System.out.println("Digite la cantidad maxima de confiteria que desea agregar.");
                        foods = new food[teclado.nextInt()];
                    } else {
                        System.out.println("Hay registrados " + foodsAgregados + " confiteria");
                    }
                    subMenu = mostrarSubMenufood(teclado, menu, foods, foodsAgregados);
                    // mover la seleccion de submenu aqui, luego de la validacion de si hay tickets agregados

                    switch (subMenu) {
                        case 1:
                            listarfood(foods);
                            break;
                        case 2:
                            foods = agregarfood(teclado,foods, foodsAgregados);
                            foodsAgregados++;
                            listarfood(foods);
                            break;
                        case 3:
                            salir = true;
                            break;
                    }
                    break;
                    
                case 7:
                    
                    salir = true;
                    break;
                default:
                    System.out.println("Opcion no valida, intente nuevamente");
            }
        }
    }

    public static int mostrarMenu(Scanner entrada) {
        System.out.println("Bienvenido al Sistema");
        System.out.println("Seleccione una menu");
        System.out.println("1. Salas");
        System.out.println("2. Tickets");
        System.out.println("3. Peliculas");
        System.out.println("4. Empleado");
        System.out.println("5. Cliente");
        System.out.println("6. Confiteria");
        System.out.println("7. Salir");
        return entrada.nextInt();
    }

    public static int mostrarSubMenu(Scanner entrada, int menu, Sala[] salas, int salasAgregadas) {
        switch (menu) {
            case 1:
                System.out.println("Seleccione una submenu");
                System.out.println("1. Listar");
                System.out.println("2. Añadir");
                System.out.println("3. Salir.");
                return entrada.nextInt();
            case 2:
                return 0;
        }
        return 0;
    }

    public static void listarSalas(Sala[] salas) {
        System.out.println("Las salas registradas son");
        for (Sala sala : salas) {
            if (sala != null) {
                System.out.println(sala.toString());
            }
        }
    }

    public static Sala[] agregarSala(Scanner teclado, Sala[] salas, int salasAgregadas) {
        System.out.println("Digite la informacion de las Salas");
        System.out.println("Capacidad:");
        int capacidad = teclado.nextInt();
        System.out.println("Numero de sala:");
        int numeroDesala = teclado.nextInt();
        System.out.println("Pelicula:");
        String pelicula = teclado.next();
        System.out.println("Tipo de sala:");
        String tipoDesala = teclado.next();
        System.out.println("Tipo de silla:");
        String tipoDesilla = teclado.next();
        
        
        Sala sala = new Sala(capacidad,numeroDesala, pelicula,tipoDesala,tipoDesilla);
        salas[salasAgregadas] = sala;
        return salas;
    }

    public static int mostrarSubMenuTickets(Scanner entrada, int menu, Ticket[] tickets, int ticketsAgregados) {
        switch (menu) {
            case 1:
                return 0;
            case 2:
                System.out.println("Seleccione una submenu");
                System.out.println("1. Listar");
                System.out.println("2. Añadir");
                System.out.println("3. Salir.");
                return entrada.nextInt();
        }
        return 0;
    }

    public static void listarTickets(Ticket[] tickets) {
        System.out.println("Los tickets registadas son");

        for (Ticket ticket : tickets) {
            if (ticket != null) {
                System.out.println(ticket.toString());
            }

        }
    }

    public static Ticket[] agregarTicket(Scanner entrada, Ticket[] tickets, int ticketsAgregados) {
        System.out.println("Digite la informacion de los tickets");
        System.out.println("Pelcula:");
        String movie = entrada.next();
        System.out.println("Precio:"); 
        double price = entrada.nextDouble();
        System.out.println("fecha:");
        String date = entrada.next();

        Ticket ticket = new Ticket(movie, price, date);
        tickets[ticketsAgregados] = ticket;
        return tickets;
    }
    
     public static int mostrarSubMenuMovies(Scanner entrada, int menu, Movie[] movies, int moviesAgregados) {
    switch (menu) {
        case 3:
            System.out.println("Seleccione una submenu");
            System.out.println("1. Listar");
            System.out.println("2. Añadir");
            System.out.println("3. Salir.");
            return entrada.nextInt();
        default:
            return 0;
    }
}

    public static void listarMovie(Movie[] movies) {
        System.out.println("Las peliculas registadas son");

        for ( Movie movie : movies) {
            if (movie != null) {
                System.out.println(movie.toString());
            }

        }
    }

   public static Movie[] agregarMovie(Scanner teclado, Movie[] movies, int moviesAgregados) {
            System.out.println("Digite la informacion de las peliculas");
    System.out.println("Nombre:");
    String name = teclado.next();
    System.out.println("Duracion:"); 
    String duration = teclado.next();
    System.out.println("Genero:"); 
    String gender = teclado.next();
    System.out.println("Rango de edad:"); 
    String age_range = teclado.next();
    System.out.println("Sinopsis"); 
    String synopsis = teclado.next();
    
   
//El simpledateformat es para formar la fecha de D/M/A
    SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/aaaaa");
    Date release_Date = null;
    while (release_Date == null) {
        System.out.println("Fecha de lanzamiento (dd/MM/aaaa):");
        String release_Date_str = teclado.next();
        try {
            release_Date = dateFormat.parse(release_Date_str);
        } catch (ParseException e) {
            System.out.println("Fecha invalida. Intente nuevamente.");
        }
    }
    

    Date available_dates = null;
    while (available_dates == null) {
        System.out.println("Fecha de disponibilidad (dd/MM/yyyy):");
        String available_dates_str = teclado.next();
        try {
            available_dates = dateFormat.parse(available_dates_str);
        } catch (ParseException e) {
            System.out.println("Fecha invalida. Intente nuevamente.");
        }
    }

    Movie movie = new Movie(name, duration,synopsis,age_range,gender );
    movies[moviesAgregados] = movie;
    return movies;
}
   
    public static int mostrarSubMenuEmployee(Scanner entrada, int menu,  Employee[] employees, int employeesAgregados) {
        switch (menu) {
            case 4:
            System.out.println("Seleccione una submenu");
            System.out.println("1. Listar");
            System.out.println("2. Añadir");
            System.out.println("3. Salir.");
            return entrada.nextInt();
        default:
            return 0;
    }
    }

    public static void listarEmployee( Employee[] employees) {
        System.out.println("Los empleados registados son");

        for (Employee employee : employees) {
            if (employee != null) {
                System.out.println(employee.toString());
            }

        }
    }

    public static Employee[] agregarEmployee(Scanner teclado,  Employee[] employees, int employeesAgregados) {
           System.out.println("Digite la informacion de las empleados");
        System.out.println("Nombre:");
        String name = teclado.next();
        System.out.println("Documento:"); 
        String document = teclado.next();
        System.out.println("Salario:");
        double salary = teclado.nextDouble();
        System.out.println("Telefono :");
        String phone=teclado.next();
        System.out.println("Tipo de empleado:");
        String type_of_employee=teclado.next();
        System.out.println("Codigo:");
        String code =teclado.next();
        System.out.println("Codigo:");
        String schedule =teclado.next();
        
        Employee employee = new Employee(name, document,salary,phone,type_of_employee,code,schedule);
        employees[employeesAgregados] = employee;
        return employees;
    }
    
    public static int mostrarSubMenuCustomer(Scanner entrada, int menu, Customer[] customers, int customersAgregados) {
        switch (menu) {
            case 5:
            System.out.println("Seleccione una submenu");
            System.out.println("1. Listar");
            System.out.println("2. Añadir");
            System.out.println("3. Salir.");
            return entrada.nextInt();
        default:
            return 0;
    }
    }

    public static void listarCustomer(  Customer[] customers) {
        System.out.println("Los clientes registados son");

        for (Customer customer : customers) {
            if (customer != null) {
                System.out.println(customer.toString());
            }

        }
    }

    public static Customer[] agregarCustomer(Scanner teclado,  Customer[] customers, int customersAgregados) {
         System.out.println("Digite la informacion de las clientes");
        System.out.println("Nombre:");
        String name = teclado.next();
        System.out.println("Documento:"); 
        String document = teclado.next();
        System.out.println("Telefono:");
        String phone = teclado.next();
        System.out.println("Tipo de cliente");
        String customer_type = teclado.next();
        System.out.println("Edad:");
        String age = teclado.next();

        Customer customer = new Customer(name, document,phone,customer_type,age);
        customers[customersAgregados] = customer;
        return customers;
    }
    
    

     private static int mostrarSubMenufood(Scanner teclado, int menu, food[] foods, int foodsAgregados) {
        switch (menu) {
            case 5:
            System.out.println("Seleccione una submenu");
            System.out.println("1. Listar");
            System.out.println("2. Añadir");
            System.out.println("3. Salir.");
            return teclado.nextInt();
        default:
            return 0;
    }
    }

    private static void listarfood(food[] foods) {
        System.out.println("Las comidas registadas son");

        for (food confectionery : foods) {
            if (confectionery != null) {
                System.out.println(confectionery.toString());
            }

        }
    }
    

    private static food[] agregarfood(Scanner teclado, food[] foods, int foodsAgregados) {
         System.out.println("Digite la informacion de las confiterias");
        System.out.println("Precio:");
        double price = teclado.nextDouble();
        System.out.println("Tipo de comida:"); 
        String kind_of_food = teclado.next();
        System.out.println("Tipo de bebida:"); 
        String kind_of_drink = teclado.next();
        System.out.println("Metodo de pago::"); 
        String payment_method = teclado.next();

        food food = new food(price,kind_of_food,kind_of_drink,payment_method);
        foods[foodsAgregados] = food;
        return foods;
    }


    private static int mostrarSubMenubox(Scanner teclado, int menu, box[] boxes, int boxesAgregados) {
         switch (menu) {
            case 5:
            System.out.println("Seleccione una submenu");
            System.out.println("1. Listar");
            System.out.println("2. Añadir");
            System.out.println("3. Salir.");
            return teclado.nextInt();
        default:
            return 0;
    }
    
    }

    private static void listarbox(box[] boxes) {
        System.out.println("Las confiterias registadas son");

        for (box confectionery : boxes) {
            if (confectionery != null) {
                System.out.println(confectionery.toString());
            }

        }
    }
    

    private static box[] agregarbox(Scanner teclado, box[] boxes, int boxesAgregados) {
         System.out.println("Digite la informacion de las cajas");
        System.out.println("Numero de caja:");
        String box_number = teclado.next();
        System.out.println("Nombre del empleado"); 
        String name_of_the_employee = teclado.next();
        System.out.println("Tipo de caja:"); 
        String type_of_box = teclado.next();
         System.out.println("Nombre del empleado"); 
        String payment_method = teclado.next();
       

        box box = new box(box_number,name_of_the_employee,type_of_box,payment_method);
        boxes[boxesAgregados] = box;
        return boxes;
    }

    
}