/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udes.cine;

/**
 *
 * @author Maria jose
 */
public class Sala {
       private String type_of_room;
    private String movie;
    private int room_number;
     private int people_capacity;
    private String type_of_chair;

    public void setType_of_room(String type_of_room) {
        this.type_of_room = type_of_room;
    }

    public void setMovie(String movie) {
        this.movie = movie;
    }

    public void setRoom_number(int room_number) {
        this.room_number = room_number;
    }

    public void setPeople_capacity(int people_capacity) {
        this.people_capacity = people_capacity;
    }

    public void setType_of_chair(String type_of_chair) {
        this.type_of_chair = type_of_chair;
    }
    
    public Sala(int room_number, int people_capacity, String type_of_room, String movie, String type_of_chair) {
        this.type_of_room = type_of_room;
        this.movie = movie;
        this.room_number = room_number;
        this.people_capacity = people_capacity;
        this.type_of_chair = type_of_chair;
    }

    public String getType_of_room() {
        return type_of_room;
    }

    public String getMovie() {
        return movie;
    }

    public int getRoom_number() {
        return room_number;
    }

    public int getPeople_capacity() {
        return people_capacity;
    }

    public String getType_of_chair() {
        return type_of_chair;
    }
    @Override
    public String toString() {
        return "sala{" + "type_of_room=" +type_of_room + ", movie=" + movie + ", room_number=" + room_number +  '}';
    }
    
}


