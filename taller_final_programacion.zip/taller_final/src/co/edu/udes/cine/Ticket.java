/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udes.cine;

/**
 *
 * @author Maria jose
 */
public class Ticket {
        private String movie;
    private double price;
    private String date;

    public Ticket() {
    }

    public Ticket(String movie, double price, String date) {
        this.movie = movie;
        this.price = price;
        this.date = date;
    }

    public String getMovie() {
        return movie;
    }

    public void setMovie(String movie) {
        this.movie = movie;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    @Override
    public String toString() {
        return "Ticket{" + "movie=" + movie + ", price=" + price + ", date=" + date + '}';
    }
    
}


