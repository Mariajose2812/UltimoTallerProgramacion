/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package co.edu.udes.supermercado;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Maria jose
 */
public class supermercado {

   public static void main(String[] args) {
       
              try {
            Scanner sc = new Scanner(System.in);
            ArrayList<employee> empleado = new ArrayList<>();
            ArrayList<customer> cliente = new ArrayList<>();

            ArrayList<producto> producto = new ArrayList<>();
            System.out.println("--Menu--");

            int option = 0;

            do {
                System.out.println("1.Personas(Empleado o cliente) \n2.Producto \n3 Salir");
                option = sc.nextInt();

                switch (option) {
                    case 1:

                        AddPerson(sc, empleado, cliente);
                        break;

                    case 2:

                        AddProduct(sc, producto);
                        break;

                    case 3:
                        listar(empleado, cliente, producto);
                }
            } while (option <= 6);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

    }

    public static void AddPerson(Scanner teclado, ArrayList<employee> empleado, ArrayList<customer> cliente) {
                System.out.println("--Sub menu personas--- \n");
        int option = 0;
        do {
            System.out.println("1.Empleado \n2.Cliente \n3.salir");
            option = teclado.nextInt();
            try {

            } catch (NumberFormatException e) {
                System.out.println("Ingrese una opción válida");
                continue;
            }

            switch (option) {
                case 1 -> {
                    System.out.println("Nombre del empleado: ");
                    String nombreEmpleado = teclado.next();

                    System.out.println("En que area trabaja el empleado");
                    String AreaEmpleado = teclado.next();

                    System.out.println("Salario del empleado");
                    double SalarioEmpleado = teclado.nextDouble();

                    System.out.println("Id del empleado");
                    int idEmpleado = teclado.nextInt();

                    empleado.add(new employee(SalarioEmpleado, AreaEmpleado, nombreEmpleado, idEmpleado));
                }
                case 2 -> {
                    System.out.println("Nombre del cliente");
                    String nombreCliente = teclado.next();

                    System.out.println("Telefono del cliente");
                    String telefonoCliente = teclado.next();

                    System.out.println("Correo cliente");
                    String correoCliente = teclado.next();

                    System.out.println("Id del cliente");
                    int IdCliente = teclado.nextInt();

                    cliente.add(new customer(telefonoCliente, correoCliente, nombreCliente, IdCliente));

                }
            }
        } while (option <= 2);
    }

    public static void AddProduct(Scanner sc, ArrayList<producto> producto) {
        System.out.println("Digite el id del producto:");
        int id = sc.nextInt();

        System.out.println("Digite el nombre del producto: ");
        String products = sc.next();

        System.out.println("Digite el precio de los productos: ");
        double precio = sc.nextDouble();

        System.out.println("Digite el tipo de producto(Limpieza,carnes, etc...): ");
        String tipe_product = sc.next();

        producto.add(new producto(id, products, precio, tipe_product));
    }

    public static void listar(ArrayList<employee> empleado, ArrayList<customer> cliente, ArrayList<producto> producto) {

        System.out.println(empleado.toString());
        System.out.println(cliente.toString());
        System.out.println(producto.toString());

    }
}
