/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udes.supermercado;

/**
 *
 * @author Maria jose
 */
public class infrastructure {
    private String address;
    private int number_of_aisles;
    private String type_of_corridors;
    private String parking_lot;
    private double infrastructure_size;

    public String getAddress() {
        return address;
    }

    public int getNumber_of_aisles() {
        return number_of_aisles;
    }

    public String getType_of_corridors() {
        return type_of_corridors;
    }

    public String getParking_lot() {
        return parking_lot;
    }

    public double getInfrastructure_size() {
        return infrastructure_size;
    }

    
    
    
    public void setAddress(String address) {
        this.address = address;
    }

    public void setNumber_of_aisles(int number_of_aisles) {
        this.number_of_aisles = number_of_aisles;
    }

    public void setType_of_corridors(String type_of_corridors) {
        this.type_of_corridors = type_of_corridors;
    }

    public void setParking_lot(String parking_lot) {
        this.parking_lot = parking_lot;
    }

    public void setInfrastructure_size(double infrastructure_size) {
        this.infrastructure_size = infrastructure_size;
    }
    
    
    
    public infrastructure(String address, int number_of_aisles, String type_of_corridors, String parking_lot, double infrastructure_size) {
        this.address = address;
        this.number_of_aisles = number_of_aisles;
        this.type_of_corridors = type_of_corridors;
        this.parking_lot = parking_lot;
        this.infrastructure_size = infrastructure_size;
    }
    
}


