/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udes.supermercado;

/**
 *
 * @author Maria jose
 */
public class customer {
     private String name;
    private String document;
    private int phone;
    private double amount;
    private String customer_type;
    public void setName(String name) {
        this.name = name;
    }

    public void setDocument(String document) {
        this.document = document;
    }

    public void setPhone(int phone) {
        this.phone = phone;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public void setCustomer_type(String customer_type) {
        this.customer_type = customer_type;
    }
   

    public customer(String name, String document, String customer_type, int phone) {
        this.name = name;
        this.document = document;
        this.phone = phone;
        this.amount = amount;
        this.customer_type = customer_type;
    }

    public String getName() {
        return name;
    }

    public String getDocument() {
        return document;
    }

    public int getPhone() {
        return phone;
    }

    public double getAmount() {
        return amount;
    }

    public String getCustomer_type() {
        return customer_type;
    }
    
}


