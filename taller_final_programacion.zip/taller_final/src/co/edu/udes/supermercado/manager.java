/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udes.supermercado;

/**
 *
 * @author Maria jose
 */
public class manager {
    private String name;
private String document;
private String schedule;
private double salary;

    public void setName(String name) {
        this.name = name;
    }

    public void setDocument(String document) {
        this.document = document;
    }

    public void setSchedule(String schedule) {
        this.schedule = schedule;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public void setCode(String code) {
        this.code = code;
    }
private String code;

    public manager(String name, String document, String schedule, double salary, String code) {
        this.name = name;
        this.document = document;
        this.schedule = schedule;
        this.salary = salary;
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public String getDocument() {
        return document;
    }

    public String getSchedule() {
        return schedule;
    }

    public double getSalary() {
        return salary;
    }

    public String getCode() {
        return code;
    }

    

    }



