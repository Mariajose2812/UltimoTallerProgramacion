/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udes.supermercado;

/**
 *
 * @author Maria jose
 */
public class schedule {
    private String Monday_to_Sunday;
    private String festive;

    public schedule(String Monday_to_Sunday, String festive) {
        this.Monday_to_Sunday = Monday_to_Sunday;
        this.festive = festive;
    }

    public String getMonday_to_Sunday() {
        return Monday_to_Sunday;
    }

    public String getFestive() {
        return festive;
    }

    
    
    
    public void setMonday_to_Sunday(String Monday_to_Sunday) {
        this.Monday_to_Sunday = Monday_to_Sunday;
    }

    public void setFestive(String festive) {
        this.festive = festive;
    }
    
}

