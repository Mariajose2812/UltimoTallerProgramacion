/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package co.edu.udes.crucigramas;

import java.util.Scanner;

/**
 *
 * @author Maria jose
 */
public class Crucigrama2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      try{
        Scanner teclado = new Scanner(System.in);
        String[] palabras = new String[5];
        int i = 0;
        while (i < palabras.length) {
            System.out.print("Escriba la palabra " + (i + 1) + ": ");
            palabras[i] = teclado.nextLine();
            i++;
        }

        i = 0;
        while (i < palabras.length) {
            System.out.println("SU PALABRA RAIZ ES: " + palabras[i]);
            int j = 0;
            while (j < palabras.length) {
                if (i == j) {
                    j++;
                    continue;
                }
                int k = 0;
                while (k < palabras[j].length()) {
                    char letra = palabras[j].charAt(k);
                    if (palabras[i].indexOf(letra) != -1) {
                        System.out.println(letra + " ENCAJA CON" + palabras[j]);
                        break;
                    }
                    k++;
                }
                j++;
            }
            i++;
        }
    }catch(Exception e){
    System.out.println(e.getMessage());
    }
    
    
    
    }
}

    
    

