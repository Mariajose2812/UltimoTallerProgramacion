/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package co.edu.udes.crucigramas;

import java.util.Scanner;

/**
 *
 * @author Maria jose
 */
public class Crucigrama1 {

    
    public static void main(String[] args) {
      
        try{
    Scanner teclado= new Scanner(System.in);
        String[] palabras = new String[5];
        int i = 0;
        do {
            System.out.print("ESCRIBA  LA PALABRA " + (i + 1) + ": ");
            palabras[i] = teclado.nextLine();
            i++;
        } while (i < palabras.length);

        i = 0;
        do {
            System.out.println("PALABRA RAIZ: " + palabras[i]);
            boolean[] letraEncajada = new boolean[palabras[i].length()]; // indica si cada letra de la palabra raíz ya encajó con alguna letra de otra palabra
            int j = 0;
            do {
                if (i == j)
                    continue;
                int k = 0;
                do {
                    char letra = palabras[j].charAt(k);
                    int index = palabras[i].indexOf(letra);
                    if (index != -1 && !letraEncajada[index]) {
                        letraEncajada[index] = true;
                        System.out.println(letra + " encaja con " + palabras[j]);
                        break; // corta el ciclo para esta palabra
                    }
                    k++;
                } while (k < palabras[j].length());
                j++;
            } while (j < palabras.length);
            i++;
        } while (i < palabras.length);
    
    }catch(Exception e){
        System.out.println(e.getMessage());
    }
    
    }
    
}

    
    
