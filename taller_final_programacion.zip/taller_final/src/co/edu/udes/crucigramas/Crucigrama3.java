/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package co.edu.udes.crucigramas;

import java.util.Scanner;

/**
 *
 * @author Maria jose
 */
public class Crucigrama3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try{
         Scanner entrada = new Scanner(System.in);
        String[] palabras = new String[5];
        for (int i = 0; i < palabras.length; i++) {
            System.out.print("Ingrese la palabra " + (i + 1) + ": ");
            palabras[i] = entrada.nextLine();
        }
        for (int i = 0; i < palabras.length; i++) {
            System.out.println("Palabra raíz: " + palabras[i]);
            boolean[] letraEncajada = new boolean[palabras[i].length()]; // indica si cada letra de la palabra raíz ya encajó con alguna letra de otra palabra
            for (int j = 0; j < palabras.length; j++) {
                if (i == j)
                    continue;
                for (int k = 0; k < palabras[j].length(); k++) {
                    char letra = palabras[j].charAt(k);
                    int index = palabras[i].indexOf(letra);
                    if (index != -1 && !letraEncajada[index]) {
                        letraEncajada[index] = true;
                        System.out.println(letra + " encaja con " + palabras[j]);
                        break; // corta el ciclo para esta palabra
                    }
                }
            }
        }
        }catch(Exception e){
            System.out.print(e.getMessage());
    }

}
}

    
    

