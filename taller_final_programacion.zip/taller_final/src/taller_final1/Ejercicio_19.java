/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package taller_final1;

import java.util.Scanner;

/**
 *
 * @author Maria jose
 */
public class Ejercicio_19 {
    
    
public static void main(String[] args) {
        try {
            Scanner teclado = new Scanner(System.in);

            System.out.print("Escriba su nombre completo: ");
            String nombreCompleto = teclado.nextLine();

            String[] palabras = nombreCompleto.split(" ");

            StringBuilder iniciales = new StringBuilder();
            for (String palabra : palabras) {
                iniciales.append(palabra.charAt(0));
            }

            System.out.printf("Las iniciales son: %s", iniciales.toString().toUpperCase());
        } catch (Exception e) {

            System.out.println(e.getMessage());
        }

    }
}
