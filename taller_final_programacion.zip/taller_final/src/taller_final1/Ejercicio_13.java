/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package taller_final1;

import java.util.Scanner;

/**
 *
 * @author Maria jose
 */
public class Ejercicio_13 {

   public static void main(String[] args) {
       
        try {
            Scanner teclado = new Scanner(System.in);
            System.out.print("Escribe el numero:");
            int numero = teclado.nextInt();

            System.out.println("La raiz cuadrada de :" + numero + "Sera:" + Math.sqrt(numero));
            System.out.println("La raiz cubica de :" + numero + "Sera:" + Math.cbrt(numero));
        } catch (Exception e) {

            System.out.println(e.getMessage());
        }

    }
}
