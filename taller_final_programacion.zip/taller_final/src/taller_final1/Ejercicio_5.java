/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package taller_final1;

import java.util.Scanner;

/**
 *
 * @author Maria jose
 */
public class Ejercicio_5 {

    public static void main(String[] args) {
        try {
            Scanner teclado = new Scanner(System.in);
            double temperatura;
            System.out.print("Escriba la temperatura:");
            temperatura = teclado.nextDouble();
            System.out.println("La temperatura en Fahrenheit:" + temperatura);

            System.out.println("La temperatura en celcius:" + (32 * temperatura - 32) * 5 / 9);
        } catch (Exception e) {

            System.out.println(e.getMessage());
        }

    }
}