/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package taller_final1;

import java.util.Scanner;

/**
 *
 * @author Maria jose
 */
public class Ejercicio_1 {

    public static void main(String[] args) {
        try {
            Scanner teclado = new Scanner(System.in);
            String nombre;
            System.out.print("¿Cual es su nombre?:");
            nombre = teclado.nextLine();
            System.out.println("Hola " + nombre);
        } catch (Exception e) {

            System.out.println(e.getMessage());
        }

    }
}