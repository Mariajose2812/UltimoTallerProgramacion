/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package taller_final1;

import java.util.Scanner;

/**
 *
 * @author Maria jose
 */
public class Ejercicio_11 {

  public static void main(String[] args) {
      
        try {
            Scanner teclado = new Scanner(System.in);

            System.out.print("Escribe el primer numero:");
            int numero1 = teclado.nextInt();

            System.out.print("Escribe el segundo numero:");
            int numero2 = teclado.nextInt();

            int distancia = Math.abs(numero1 - numero2);
            System.out.print("La distancia de los dos numeros sera de:" + distancia);
        } catch (Exception e) {

            System.out.println(e.getMessage());
        }

    }
}
