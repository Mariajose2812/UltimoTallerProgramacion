/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package taller_final1;

import java.util.Scanner;

/**
 *
 * @author Maria jose
 */
public class Ejercicio_12 {

     public static void main(String[] args) {
        try {
            Scanner teclado = new Scanner(System.in);

            System.out.print("Escriba el primer valor de X:");
            int x1 = teclado.nextInt();

            System.out.print("Escriba el primer valor de Y:");
            int y1 = teclado.nextInt();

            System.out.print("Escriba el segundo valor de X:");
            int x2 = teclado.nextInt();

            System.out.print("Escriba el segundo valor de Y:");
            int y2 = teclado.nextInt();

            System.out.print("La distancia de estos puntos seran:" + Math.sqrt(Math.abs(x2 - x1) * 2) + (y2 - y1) * 2);
        } catch (Exception e) {

            System.out.println(e.getMessage());
        }

    }
}