/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package taller_final1;

import java.util.Scanner;

/**
 *
 * @author Maria jose
 */
public class Ejercicio_16 {

    public static void main(String[] args) {
        
        try {
            Scanner teclado = new Scanner(System.in);

            System.out.print("Escribe la velocidad del primer vehiculo:");
            double velocidad1 = teclado.nextDouble();

            System.out.print("Escribe la velocidad del segundo vehiculo:");
            double velocidad2 = teclado.nextDouble();

            while (velocidad1 >= velocidad2) {

                System.out.println("La velocidad 2 debe ser mayor");
                System.exit(0);
            }

            System.out.print("Escriba la distancia de los vehiculos:");
            double distancia = teclado.nextDouble();

            System.out.println("La velocidad del primer vehiculo sera:" + velocidad1 + "km");

            System.out.println("La velocidad del segundo vehiculo sera:" + velocidad2 + "km");

            System.out.println("La distancia de los vehiculos sera:" + distancia + "metros");

            double tiempoAlcance = Math.abs(distancia / (velocidad1 - velocidad2) * 60);

            System.out.println("El vehículo más rápido alcanzará al otro en " + tiempoAlcance + " minutos.");
        } catch (Exception e) {

            System.out.println(e.getMessage());
        }

    }
}
