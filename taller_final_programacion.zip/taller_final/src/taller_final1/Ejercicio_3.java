/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package taller_final1;

import java.util.Scanner;

/**
 *
 * @author Maria jose
 */
public class Ejercicio_3 {

    public static void main(String[] args) {
        try {
            Scanner teclado = new Scanner(System.in);

            System.out.print("Escriba la longitud del primer lado: ");
            double lado1 = teclado.nextDouble();

            System.out.print("Escriba la longitud del segundo lado: ");
            double lado2 = teclado.nextDouble();

            double hipotenusa = Math.sqrt(Math.pow(lado1, 2) + Math.pow(lado2, 2));

            System.out.println("La hipotenusa del triángulo rectángulo es: " + hipotenusa);
        } catch (Exception e) {

            System.out.println(e.getMessage());
        }

    }
}
