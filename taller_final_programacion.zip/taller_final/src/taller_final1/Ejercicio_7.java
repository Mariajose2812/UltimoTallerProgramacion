/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package taller_final1;

import java.util.Scanner;

/**
 *
 * @author Maria jose
 */
public class Ejercicio_7 {
    
 public static void main(String[] args) {
        try {
            Scanner teclado = new Scanner(System.in);
            int minutos;
            System.out.print("Escriba la cantidad de minutos:");
            minutos = teclado.nextInt();
            System.out.println("La cantidad de horas sera:" + (minutos / 60));
            System.out.println("La cantidad de segundos sera::" + (minutos * 60));
        } catch (Exception e) {

            System.out.println(e.getMessage());
        }

    }
}
