/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package taller_final1;

import java.util.Scanner;

/**
 *
 * @author Maria jose
 */
public class Ejercicio_9 {

   public static void main(String[] args) {
       
        try {
            Scanner teclado = new Scanner(System.in);
            int Venta;
            System.out.print("Escriba el valor de la venta:");
            Venta = teclado.nextInt();
            int Descuento = (Venta * 15) / 100;
            System.out.print("El Total de la venta sera:" + (Venta - Descuento));

        } catch (Exception e) {

            System.out.println(e.getMessage());
        }

    }
}
