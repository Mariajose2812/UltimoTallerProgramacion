/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package taller_final1;

import java.util.Scanner;

/**
 *
 * @author Maria jose
 */
public class Ejercicio_20 {

    public static void main(String[] args) {
        
        try {
            Scanner teclado = new Scanner(System.in);
            System.out.print("¿Cuántas monedas de 2 euros tienes? ");
            int monedas2 = teclado.nextInt();

            System.out.print("¿Cuántas monedas de 1 euro tienes? ");
            int monedas1 = teclado.nextInt();

            System.out.print("¿Cuántas monedas de 50 céntimos tienes? ");
            int monedas50 = teclado.nextInt();

            System.out.print("¿Cuántas monedas de 20 céntimos tienes? ");
            int monedas20 = teclado.nextInt();

            System.out.print("¿Cuántas monedas de 10 céntimos tienes? ");
            int monedas10 = teclado.nextInt();

            double totalEuros = monedas2 * 2 + monedas1 * 1 + monedas50 * 0.5 + monedas20 * 0.2 + monedas10 * 0.1;
            int euros = (int) totalEuros;
            int centimos = (int) ((totalEuros - euros) * 100);

            System.out.printf("Tienes %d euros y %d céntimos", euros, centimos);
        } catch (Exception e) {

            System.out.println(e.getMessage());
        }

    }
}