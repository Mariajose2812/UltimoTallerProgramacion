/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package taller_final1;

import java.util.Scanner;

/**
 *
 * @author Maria jose
 */
public class Ejercicio_10 {

   public static void main(String[] args) {
       
        try {
            Scanner teclado = new Scanner(System.in);

            System.out.println("Escriba la calificación del primer parcial: ");
            double parcial1 = teclado.nextDouble();

            System.out.println("Escriba la calificación del segundo parcial: ");
            double parcial2 = teclado.nextDouble();

            System.out.println("Escriba la calificación del tercer parcial: ");
            double parcial3 = teclado.nextDouble();

            System.out.println("Escriba la calificación del examen final: ");
            double examenFinal = teclado.nextDouble();

            System.out.println("Escriba la calificación del trabajo final: ");
            double trabajoFinal = teclado.nextDouble();

            double promedioParciales = (parcial1 + parcial2 + parcial3) / 3;

            double calificacionFinal = (promedioParciales * 0.55) + (examenFinal * 0.3) + (trabajoFinal * 0.15);

            System.out.println("La calificación final es: " + calificacionFinal);
        } catch (Exception e) {

            System.out.println(e.getMessage());
        }

    }
}