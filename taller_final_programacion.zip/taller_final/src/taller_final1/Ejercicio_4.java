/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package taller_final1;

import java.util.Scanner;

/**
 *
 * @author Maria jose
 */
public class Ejercicio_4 {

    public static void main(String[] args) {
        try {
            Scanner teclado = new Scanner(System.in);

            System.out.print("Escriaba un numero de dos cifras:");
            int numero = teclado.nextInt();
            int numeroInvertido = 0;

            while (numero != 0) {
                int digito = numero % 10;
                numeroInvertido = numeroInvertido * 10 + digito;
                numero /= 10;
            }

            System.out.println("Número invertido es: " + numeroInvertido);
        } catch (Exception e) {

            System.out.println(e.getMessage());
        }

    }
}