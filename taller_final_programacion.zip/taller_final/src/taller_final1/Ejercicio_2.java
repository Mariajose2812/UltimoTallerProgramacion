/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package taller_final1;

import java.util.Scanner;

/**
 *
 * @author Maria jose
 */
public class Ejercicio_2 {

   public static void main(String[] args) {
        try {
            Scanner teclado = new Scanner(System.in);
            double altura;
            double base;
            System.out.print("Escriba su base:");
            base = teclado.nextDouble();
            System.out.println("Escriba su altura:");
            altura = teclado.nextDouble();
            System.out.println("El perimetro es:" + (base + altura));
            System.out.println("La altura es:" + (base * altura) / 2);
        } catch (Exception e) {

            System.out.println(e.getMessage());
        }

    }
}
