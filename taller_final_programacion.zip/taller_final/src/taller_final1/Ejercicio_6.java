/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package taller_final1;

import java.util.Scanner;

/**
 *
 * @author Maria jose
 */
public class Ejercicio_6 {

    public static void main(String[] args) {
        try {
            Scanner teclado = new Scanner(System.in);
            System.out.print("Escriba el primer número: ");
            double num1 = teclado.nextDouble();

            System.out.print("Escriba el segundo número: ");
            double num2 = teclado.nextDouble();

            System.out.print("Escriba el tercer número: ");
            double num3 = teclado.nextDouble();

            System.out.print("Escriba el cuarto número: ");
            double num4 = teclado.nextDouble();

            double media = (num1 + num2 + num3 + num4) / 4;

            System.out.println("La media de los números escritos son: " + media);
        } catch (Exception e) {

            System.out.println(e.getMessage());
        }

    }
}