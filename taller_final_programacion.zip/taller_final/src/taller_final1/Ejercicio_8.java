/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package taller_final1;

import java.util.Scanner;

/**
 *
 * @author Maria jose
 */
public class Ejercicio_8 {

   public static void main(String[] args) {
       
        try {
            Scanner teclado = new Scanner(System.in);

            System.out.print("Escriba el sueldo base del vendedor: ");
            double sueldoBase = teclado.nextDouble();

            System.out.print("Escriba el monto de la primera venta: ");
            double venta1 = teclado.nextDouble();

            System.out.print("Escriba el monto de la segunda venta: ");
            double venta2 = teclado.nextDouble();

            System.out.print("Escriba el monto de la tercera venta: ");
            double venta3 = teclado.nextDouble();

            double comisionTotal = (venta1 + venta2 + venta3) * 0.1;

            double salarioTotal = sueldoBase + comisionTotal;

            System.out.println("La comisión total por las tres ventas realizadas es: " + comisionTotal);
            System.out.println("El salario total del vendedor en el mes es: " + salarioTotal);
            
        } catch (Exception e) {

            System.out.println(e.getMessage());
        }

    }
}
