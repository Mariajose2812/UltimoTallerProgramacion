/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package taller_final2;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author Maria jose
 */
public class Ejercicio_11 {
    
 public static void main(String[] args) {
        try {
            Scanner teclado = new Scanner(System.in);
         
            Random rand = new Random();
            int numProductos = rand.nextInt(23) + 1;
            System.out.println("EL NUMERO DE PRODUCTOS VA A SER: " + numProductos);
            String[] productos = new String[numProductos];
            int[] cantidades = new int[numProductos];
            double[] precios = new double[numProductos];

            int i = 0;
            while (i < numProductos) {
                System.out.println("INGRESE EL NOMBRE DEL PRODUCTO " + (i + 1) + ":");
                productos[i] = teclado.nextLine();
                System.out.println("INGRESE LA CANTIDAD DEL PRODUCTO " + (i + 1) + ":");
                cantidades[i] = teclado.nextInt();
                System.out.println("INGRESE EL PRECIO DEL PRODUCTO " + (i + 1) + ":");
                precios[i] = teclado.nextDouble();
                teclado.nextLine();
                i++;
            }
            System.out.println("Productos:");
            for (i = 0; i < numProductos; i++) {
                System.out.println(productos[i] + " - " + cantidades[i] + " -$ " + precios[i]);
            }
        } catch (Exception e) {

            System.out.println(e.getMessage());

        }

    }
}
