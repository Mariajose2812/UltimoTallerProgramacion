/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package taller_final2;

import java.util.Scanner;

/**
 *
 * @author Maria jose
 */
public class Ejercicio_5 {

  public static void main(String[] args) {
        try {
            String cadena = "";

            if (cadena.equals("")) {
                
                Scanner teclado = new Scanner(System.in);
                System.out.print("Introduzca una cadena de texto: ");
                cadena = teclado.nextLine();
            }

        } catch (Exception e) {

            System.out.println(e.getMessage());

        }
    }

    public static String InvertirCadena(String cadena) {
        String cadenaInvertida = "";
        for (int i = cadena.length() - 1; i >= 0; i--) {
            cadenaInvertida = cadenaInvertida + cadena.charAt(i);
        }
        return cadenaInvertida;
    }

}
