/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package taller_final2;

import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author Maria jose
 */
public class Ejercicio_2 {

    public static void main(String[] args) {
        try {
            int numeroRandom = (int) Math.floor(Math.random() * 31 + 1);
            
            Scanner teclado = new Scanner(System.in);

            double suma = 0;
            int contadorModa = 0;
            double moda = 0;
            int currentContador;
            double currentNumero;

            System.out.println("El numero aleatorio es: " + numeroRandom);

            double[] numeros = new double[numeroRandom];

            int i = 0;
            do {
                System.out.println("Escriba un numero: " + (i + 1) + ":");
                numeros[i] = teclado.nextDouble();
                suma += numeros[i];
                i++;
            } while (i < numeroRandom);

            Arrays.sort(numeros);
           
            double mediana;
            if (numeroRandom % 2 == 0) {
                mediana = (numeros[numeroRandom / 2 - 1] + numeros[numeroRandom / 2]) / 2;
            } else {
                mediana = numeros[numeroRandom / 2];
            }
            
            for (i = 0; i < numeroRandom; i++) {
                currentNumero = numeros[i];
                currentContador = 0;
                for (int j = 0; j < numeroRandom; j++) {
                    if (numeros[j] == currentNumero) {
                        currentContador++;
                    }
                }
                if (currentContador > contadorModa) {
                    contadorModa = currentContador;
                    moda = currentNumero;
                }
            }
          
            double media = suma / numeroRandom;

            System.out.println("La media: " + media);
            System.out.println("La mediana: " + mediana);
            System.out.println("La moda: " + moda);
        } catch (Exception e) {

            System.out.println(e.getMessage());

        }

    }
}
