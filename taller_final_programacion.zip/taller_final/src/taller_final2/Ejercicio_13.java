/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package taller_final2;

import java.util.Scanner;

/**
 *
 * @author Maria jose
 */
public class Ejercicio_13 {

   public static void main(String[] args) {
       
        try {
            Scanner teclado = new Scanner(System.in);
            System.out.println("INGRESE LA PALABRA RAIZ: ");
            String palabraRaiz = teclado.nextLine();
            System.out.println("INGRESE 4 PALABRAS MAS: ");
            String[] palabras = new String[4];
            for (int i = 0; i < 4; i++) {
                palabras[i] = teclado.nextLine();
            }

            for (String palabra : palabras) {
                for (int i = 0; i < palabra.length(); i++) {
                    if (palabraRaiz.contains(String.valueOf(palabra.charAt(i)))) {
                        System.out.println("La palabra " + palabra + " encaja en la palabra base");
                        break;
                    }
                }
            }
        } catch (Exception e) {

            System.out.println(e.getMessage());

        }

    }
}
