/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package taller_final2;

import java.util.Scanner;

/**
 *
 * @author Maria jose
 */
public class Ejercicio_8 {
    
    
public static void main(String[] args) {
        try {
            Scanner teclado = new Scanner(System.in);

            System.out.print("Escriba una cadena de texto: ");
            String palabra = teclado.nextLine();

            char[] reverso = new char[palabra.length()];
            int j = 0;
            for (char c : palabra.toCharArray()) {
                reverso[j++] = c;
            }

            System.out.print("la inversa es: ");
            for (int i = reverso.length - 1; i >= 0; i--) {
                System.out.print(reverso[i]);
            }
        } catch (Exception e) {

            System.out.println(e.getMessage());

        }

    }
}
