/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package taller_final2;

import java.util.Scanner;

/**
 *
 * @author Maria jose
 */
public class Ejercicio_15 {

     public static void main(String[] args) {
         
        try {
            Scanner teclado = new Scanner(System.in);
            System.out.println("Ingrese la palabra raiz: ");
            String palabraRaiz = teclado.nextLine();

            String[] palabras = new String[4];
            int i = 0;
            while (i < 4) {
                System.out.println("Ingrese una palabra: ");
                palabras[i] = teclado.nextLine();
                i++;
            }

            for (String palabra : palabras) {
                for (int j = 0; j < palabra.length(); j++) {
                    if (palabraRaiz.contains(String.valueOf(palabra.charAt(j)))) {
                        System.out.println("La palabra " + palabra + " encaja en la palabra base");
                        break;
                    }
                }
            }
        } catch (Exception e) {

            System.out.println(e.getMessage());

        }

    }
}
