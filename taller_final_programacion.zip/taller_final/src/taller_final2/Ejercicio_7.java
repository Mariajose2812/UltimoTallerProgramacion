/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package taller_final2;

import java.util.Scanner;

/**
 *
 * @author Maria jose
 */
public class Ejercicio_7 {

    
    public static void main(String[] args) {
        try {
            Scanner teclado = new Scanner(System.in);
            int Tamaño = 0;
            String cadena;
            String cadenaInvertida = "";

            System.out.println("DIGITE UNA CADENA DE TEXTO:");
            cadena = teclado.nextLine();

            Tamaño = cadena.length() - 1;
          
            do {
                cadenaInvertida = cadenaInvertida + cadena.charAt(Tamaño);
                Tamaño = Tamaño - 1;

            } while (Tamaño >= 0);

            System.out.println("CADENA ACTUAL ES :" + cadena);
            System.out.println("CADENA INVERTIDA ES :" + cadenaInvertida);
        } catch (Exception e) {

            System.out.println(e.getMessage());

        }

    }
}
