/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package taller_final2;

import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author Maria jose
 */
public class Ejercicio_3 {

    public static void main(String[] args) {
        try {
            int numeroRandom = (int) Math.floor(Math.random() * 31 + 1);
            
            Scanner teclado = new Scanner(System.in);
            System.out.println("SU NUMERO RANDOM VA A SER :" + numeroRandom);
            int n = numeroRandom;
            int[] numeros = new int[numeroRandom];
            int i = 0;
            while (i < n) {
                System.out.print("INGRESE UN NUMERO " + (i + 1) + ":");
                numeros[i] = teclado.nextInt();
                i++;
            }
            
            Arrays.sort(numeros);
            double mediana;
            if (n % 2 == 0) {
                mediana = (numeros[n / 2 - 1] + numeros[n / 2]) / 2.0;
            } else {
                mediana = numeros[n / 2];
            }

            
            int suma = 0;
            for (int num : numeros) {
                suma += num;
            }
            double media = (double) suma / n;

           
            int cuentaMax = 0;
            int moda = numeros[0];
            int cuenta = 1;
            for (i = 1; i < n; i++) {
                if (numeros[i] == numeros[i - 1]) {
                    cuenta++;
                } else {
                    if (cuenta > cuentaMax) {
                        cuentaMax = cuenta;
                        moda = numeros[i - 1];
                    }
                    cuenta = 1;
                }
            }
            System.out.println("La media es: " + media);
            System.out.println("La mediana es: " + mediana);
            System.out.println("La moda es: " + moda);
        } catch (Exception e) {

            System.out.println(e.getMessage());

        }

    }
}
